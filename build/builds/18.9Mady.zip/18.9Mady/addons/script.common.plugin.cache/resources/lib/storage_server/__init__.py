# -*- coding: utf-8 -*-
"""
    Copyright (C) 2019 anxdpanic

    This file is part of script.common.plugin.cache

    SPDX-License-Identifier: GPL-3.0-only
    See LICENSES/GPL-3.0-only.txt for more information.
"""

__all__ = ['StorageServer', 'storageserverdummy']
